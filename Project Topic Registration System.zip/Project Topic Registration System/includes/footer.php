    <!--Footer-->
    <footer class="text-center">
        <div class="container">
            <div class="row p-3">
                <div class="col-md-4">
                    <p class="footer-links"><a href="#">Terms of Use</a> <a href="#">Privacy Policy</a></p>
                </div>
                <div class="col-md-4"> <small> Copyright &copy; 2023 All Rights Reserved. </small></div>
                <div class="col-md-4">
                </div>
            </div>
        </div>
    </footer>
    </body>

    </html>